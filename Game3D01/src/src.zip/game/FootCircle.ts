import { ui } from "./../ui/layaMaxUI";
    export default class FootCircle extends ui.test.HeroFootUI {
    
    constructor() { super(); }
}