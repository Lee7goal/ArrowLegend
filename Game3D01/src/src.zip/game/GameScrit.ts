export default class GameScirt extends Laya.Script3D{
    constructor(){
        super();
    }
}