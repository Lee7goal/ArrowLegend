export default class HitType{
    /**发抖 */
    static hit1:number = 1;
    /**后退 */
    static hit2:number = 2;
    /**打扁 */
    static hit3:number = 3;
    /**左右晃 */
    static hit4:number = 4;
}