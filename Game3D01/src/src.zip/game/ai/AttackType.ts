export default class AttackType{
    static TAG:string = "ATTACK";

    /**冲撞 */
    static FLYHIT:number = 1;
    /**子弹 */
    static BULLET:number = 2;
}