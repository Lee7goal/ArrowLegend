export default class GameProType{
    /**主角对象*/
    static Hero:number = 9999;
    /**蓝色石头怪*/
    static RockGolem_Blue:number = 8000;
    /**石头怪石头*/
    static Rock:number = 801;

    //子弹类别<=800;
    /**主角箭*/
    static HeroArrow:number = 799;
    /**怪物箭*/
    static MonstorArrow:number = 798;
}