import GamePro from "../GamePro";

export abstract class BaseSkill {
    exeSkill(monster:GamePro):void{}
}