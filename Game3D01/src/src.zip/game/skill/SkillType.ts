export default class SkillType{
    static TAG:string = "SKILL";
    /**分裂 */
    static SPLIT:number = 1;
}