import { ui } from "./../../../../ui/layaMaxUI";
    export default class NPC_1003 extends ui.test.huziUI {
    constructor() { super(); }
}