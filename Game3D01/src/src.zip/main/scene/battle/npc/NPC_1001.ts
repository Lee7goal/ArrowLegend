import { ui } from "./../../../../ui/layaMaxUI";
    export default class NPC_1001 extends  ui.test.tianshiUI{
    constructor() { super(); }
}