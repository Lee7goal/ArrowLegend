import { ui } from "./../../../../ui/layaMaxUI";
    export default class NPC_1002 extends  ui.test.moguiUI{
    constructor() { super(); }
}