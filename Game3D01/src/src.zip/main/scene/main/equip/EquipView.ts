import { ui } from "../../../../ui/layaMaxUI";
    export default class EquipView extends ui.test.equipUI {
    
    constructor() { super(); }
}