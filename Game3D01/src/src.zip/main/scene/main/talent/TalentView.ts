import { ui } from "../../../../ui/layaMaxUI";
    export default class TalentView extends ui.test.talentUI {
    
    constructor() { super(); }
}