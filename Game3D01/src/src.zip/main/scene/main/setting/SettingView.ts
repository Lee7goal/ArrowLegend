import { ui } from "../../../../ui/layaMaxUI";
    export default class SettingView extends ui.test.settingUI {
    
    constructor() { super(); }
}