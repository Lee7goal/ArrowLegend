import { ui } from "../../../../ui/layaMaxUI";
    export default class ShopView extends ui.test.shopUI {
    
    constructor() { super(); }
}