export default class SysSkill{
    static NAME:string = 'sys_enemyskill.txt';

    public id:number = 0;
    public name:string = '';
    public effectType:number = 0;
    public effect1:number = 0;
}