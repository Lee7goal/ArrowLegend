export default class SysBullet{
    static NAME:string = 'sys_bullet.txt';
    public id:number = 0;
    public bulletMode:number = 0;
    public boomEffect:number = 0;
    public bulletSpeed:number = 0;
    public bulletBlock:number = 0;
    public bulletsAoe:number = 0;
    public bulletEjection:number = 0;
    public ejectionNum:number = 0;
    public txt:string = '';
}